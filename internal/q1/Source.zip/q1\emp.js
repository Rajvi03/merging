[{_id:1,Name:"Reena",Address:"Ahmedabad",Salary:30000,Department:"HR"},

{_id:2,Name:"mehna",Address:"Calcutta",Salary:50000,Department:"Accountant"},

{_id:3,Name:"Rahul",Address:"Delhi",Salary:10000,Department:"Sales"},

{_id:4,Name:"Rita",Address:"Mumbai",Salary:20000,Department:"Accountant"},

{_id:5,Name:"Rohit",Address:"Ahmedabad",Salary:30000,Department:"HR"}]