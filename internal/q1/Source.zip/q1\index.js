const express = require('express')
const app=express()
const fs = require('fs')
app.use(express.json())
app.get('/',(req,res)=>{
    fs.readFile('emp.js',(err,data)=>{
        if(err) return console.log(err)
        res.send(data)
        res.end()
    })
})
app.put('/edit/:id','utf8'(req,res)=>{
    fs.readFile('emp.js',(err,data)=>{
        if(err) return console.log(err)
        var obj=req.body
        console.log(data)
        var employee=data.find((item=>{return item.id==req.params.id}))
        console.log(employee)
        if(employee.Department=="HR" || employee.Department=="sales"){
                employee._id=req.params.id,
            employee.Name=obj.Name,
            employee.Address=obj.Address,
            employee.Salary=obj.Salary,
            employee.Department=obj.Department
            employee.push(req.body)
                
            fs.writeFile('emp.js',JSON.stringify(employee),(err,data)=>{
                if(err) return console.log(err)
            })
            res.send(employee)
        }
        else{
            console.log('employee is not from this department or sales')
            return res.send('employee is not from this department or sales')
        }
    })
})
app.listen(4000,()=>{console.log('listen port no 4000')})