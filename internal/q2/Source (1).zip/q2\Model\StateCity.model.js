const mongoose = require('mongoose')

const State=mongoose.model('state',new mongoose.Schema({
    stateID:{type:String,required:true}
    ,Name:{type:String,required:true},
    Cities:[{type:Array,required:true}]
}))
module.exports=State