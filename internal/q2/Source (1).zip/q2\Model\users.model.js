const mongoose = require('mongoose')
const User=mongoose.model('user',new mongoose.Schema({
    userID:{type:Number,required:true},
    Name:{type:String,required:true},
    Password:{type:String,required:true},
    DOB:{type:Date,required:true},
    DOJ:{type:Date,required:true},
    PanCard:{type:String,required:true},
    City:{type:Number,required:true},
    stateid:{type:Number,required:true},
    cityid:{type:Number,required:true},
    ReportingHead:{type:String,required:true}
}))
module.exports=User