const mongoose= require('mongoose')
const User=require('./Model/users.model')
const State=require('./Model/StateCity.model')
const express = require('express')
const app=express()
app.use(express.json())
mongoose.connect('mongodb://localhost:27017/Signacompany')
.then(()=>{console.log('conntected to mongo db')})
.catch(err=>{console.error('couldnt connect to mongodb',err)})
app.get('/sameCityEmp')
app.listen(4000,()=>{console.log('listening on port number:4000')})
async function EachcityEmpNo(){
    try{
        var city=await State.find().select('Cities')
        var emp=await User.find().select('City')
        for(var i=0;i<city.length;i++){
            for(var j=0;j<city.length;j++){
                if(cityi)
            }
        }
        console.log(emp)    
    }
    catch(err){
        console.log(err)
    }
}
EachcityEmpNo()