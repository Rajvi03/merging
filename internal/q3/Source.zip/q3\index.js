 function  login(username,gender){
    var date= new Date()
    var obj={name:username,LoginDate:{currenttime:date,Gender:gender},hello:username};
    var promise =  new Promise(function(resolve, reject){
        setTimeout(()=>{
            if(username==' '){
                message='user name is empty'
                reject(message)
            }
            else{
                message=obj
                resolve(obj)
            }
        },1000)
    })
      promise.then(resolve=>{console.log(resolve)}).catch(reject=>console.log(reject))
}
var result= login('Abhishek','male')
console.log(`${result}`)
function greeting(username,gender,result){
    if(gender=='male'){
        var obj=`Hello, Mr. ${username} login an ${result}`
    }
    else if(gender=='female'){
        var obj=`Hello, Ms. ${username} login an ${result}`
    }
    console.log(obj)
}
greeting('abhishek','male',result)