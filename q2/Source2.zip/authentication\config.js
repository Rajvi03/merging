module.exports ={
    secretKey:"jeetraythatha001",
    algorithm:"RS256",
    expiresIn:"15m"
}